package Person;


/**
 *
 * @author henriette
 * Liang oppgave 11.2
 */
public class Person {
    protected String name, address, phone, email;
    
    public Person(String name, String address, String phone, String email){
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
    } 
    
    public void SetName(String name){
        this.name = name;
    }
    
    public void SetAddress(String address){
        this.address = address;
    }
    
    public void SetPhone(String phone){
        this.phone = phone;
    }
    
    public void SetEmail(String email){
        this.email = email;
    }
    
    public String GetName(){
        return name;
    }
    
     public String GetAddress(){
        return address;
    }
    
    public String GetPhone(){
        return phone;
    }
    
    public String GetEmail(){
        return email;
    }
    
    public String ToString(){
        return ("Name: " + name +", address: " + address + "\n" +
                "Phone: " + phone + "\n" +
                "eMail: " + email);
    }
}
